const question = document.querySelector('#question');
const choices = Array.from(document.querySelectorAll('.choice-text'));
const progressText = document.querySelector('#progressText');
const scoreText = document.querySelector('#score');
const progressBarFull = document.querySelector('#progressBarFull');

let currentQuestion = {};
let acceptingAnswers = true;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
    {
        question: 'How is a variable declared in JavaScript?',
        choice1: 'let myVar;',
        choice2: 'variable myVar;',
        choice3: 'var myVar;',
        answer: 1,
    },
    {
        question: 'How do you create a function in JavaScript?',
        choice1: 'myFunction => {};',
        choice2: 'function myFunction() {}',
        choice3: 'let myFunction = function() {};',
        answer: 2,
    },
    {
        question: 'How do you use the if operator to check if the variable "x" is less than 10?',
        choice1: 'if x < 10 then {}',
        choice2: 'if (x < 10) {}',
        choice3: 'if (x > 10) {}',
        answer: 2,
    },
    {
        question: 'How in JavaScript do you define an array with "apple" and "banana" elements?',
        choice1: 'array fruits = ["apple", "banana"];',
        choice2: 'var fruits = {"apple", "banana"};',
        choice3: 'let fruits = ["apple", "banana"];',
        answer: 3,
    },
    {
        question: 'What is an object in JavaScript?',
        choice1: 'Tape',
        choice2: 'Data storage container',
        choice3: 'Array',
        answer: 2,
    },
    {
        question: 'What function in JavaScript is used to create a class?',
        choice1: 'createClass()',
        choice2: 'defineClass()',
        choice3: 'class',
        answer: 3,
    },
    {
        question: 'How can I inherit a class in JavaScript?',
        choice1: 'Using the extends keyword',
        choice2: 'Using the keyword implements',
        choice3: 'Using the keyword inherit',
        answer: 1,
    },
    {
        question: 'How can I create an instance of a class in JavaScript?',
        choice1: 'const obj = new MyClass();',
        choice2: 'const obj = MyClass.create();',
        choice3: 'const obj = create(MyClass);',
        answer: 1,
    },
    {
        question: 'What is polymorphism in the context of JavaScript?',
        choice1: 'Ability of objects of different classes to have the same methods',
        choice2: 'Ability to change the type of variable at any time',
        choice3: 'The ability of an object to have many properties',
        answer: 1,
    },
    {
        question: 'What is a class constructor in JavaScript?',
        choice1: 'Method for creating a new class',
        choice2: 'Method for creating a new class object',
        choice3: 'Method for deleting a class object',
        answer: 2,
    },
];

const SCORE_POINTS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    getNewQuestion();
};

getNewQuestion = () => {
    if (availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        localStorage.setItem('mostRecentScore', score);
        return window.location.assign('/endjs.html'); 
    }
    

    questionCounter++;
    progressText.innerText = `Question ${questionCounter} of ${MAX_QUESTIONS}`;
    progressBarFull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

    const questionsIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionsIndex];
    question.innerText = currentQuestion.question;

    choices.forEach((choice) => {
        const number = choice.dataset['number'];
        choice.innerText = currentQuestion['choice' + number];
    });

    availableQuestions.splice(questionsIndex, 1);

    acceptingAnswers = true;
};

choices.forEach((choice) => {
    choice.addEventListener('click', (e) => {
        if (!acceptingAnswers) return;

        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset['number'];

        let classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';

        if (classToApply === 'correct') {
            incrementScore(SCORE_POINTS);
        }

        selectedChoice.parentElement.classList.add(classToApply);

        setTimeout(() => {
            selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        }, 1000);
    });
});

incrementScore = (num) => {
    score += num;
    scoreText.innerText = score;
};

startGame();
