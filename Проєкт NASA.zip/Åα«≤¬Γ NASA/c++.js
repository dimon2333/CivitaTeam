const question = document.querySelector('#question');
const choices = Array.from(document.querySelectorAll('.choice-text'));
const progressText = document.querySelector('#progressText');
const scoreText = document.querySelector('#score');
const progressBarFull = document.querySelector('#progressBarFull');

let currentQuestion = {};
let acceptingAnswers = true;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
    {
        question: 'How is a pointer to an integer declared in C++?',
        choice1: 'int *ptr;',
        choice2: 'ptr int;',
        choice3: 'pointer = int;',
        answer: 1,
    },
    {
        question: 'Given an array of 5 elements in C++, how do you access the third element?',
        choice1: 'array[3];',
        choice2: 'array[2];',
        choice3: 'array[4];',
        answer: 2,
    },
    {
        question: 'How in C++ do you define a constant that cannot be changed after initialization?',
        choice1: 'int constant(42);',
        choice2: 'const int constant = 42;',
        choice3: 'int constant = const 42;',
        answer: 2,
    },
    {
        question: 'What does the new operator do in C++?',
        choice1: 'Delete dynamically allocated memory for an object',
        choice2: 'Performs output on display',
        choice3: 'Removes an object from memory',
        answer: 1,
    },
    {
        question: 'What is a class in C++?',
        choice1: 'Object',
        choice2: 'Data type',
        choice3: 'Template',
        answer: 2,
    },
    {
        question: 'What are the basic principles of OOP includes the language C++?',
        choice1: 'Encapsulation, inheritance, polymorphism',
        choice2: 'Conditional operators, cycles, functions',
        choice3: 'Arrays, pointers, structures',
        answer: 1,
    },
    {
        question: 'What is a class constructor?',
        choice1: 'Method for creating a class object',
        choice2: 'Method for deleting a class object',
        choice3: 'Method for changing object type',
        answer: 1,
    },
    {
        question: 'How can you inherit a class in C++?',
        choice1: 'Using the class keyword',
        choice2: 'Using the keyword implements',
        choice3: 'Using the extends keyword',
        answer: 3,
    },
    {
        question: 'How can you access class members if they have a "private" access modifier?',
        choice1: 'Using the "." (dot)',
        choice2: 'Using the operator "->"',
        choice3: 'Private members cannot be accessed from outside the class',
        answer: 1,
    },
    {
        question: 'What is polymorphism in OOP?',
        choice1: 'Ability of a class to have many constructors',
        choice2: 'Ability of objects of different classes to have the same named methods',
        choice3: 'Ability of a class to have many hereditary classes',
        answer: 2,
    },
];

const SCORE_POINTS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    getNewQuestion();
};

getNewQuestion = () => {
    if (availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        localStorage.setItem('mostRecentScore', score);
        return window.location.assign('/endc++.html'); 
    }
    

    questionCounter++;
    progressText.innerText = `Question ${questionCounter} of ${MAX_QUESTIONS}`;
    progressBarFull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

    const questionsIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionsIndex];
    question.innerText = currentQuestion.question;

    choices.forEach((choice) => {
        const number = choice.dataset['number'];
        choice.innerText = currentQuestion['choice' + number];
    });

    availableQuestions.splice(questionsIndex, 1);

    acceptingAnswers = true;
};

choices.forEach((choice) => {
    choice.addEventListener('click', (e) => {
        if (!acceptingAnswers) return;

        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset['number'];

        let classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';

        if (classToApply === 'correct') {
            incrementScore(SCORE_POINTS);
        }

        selectedChoice.parentElement.classList.add(classToApply);

        setTimeout(() => {
            selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        }, 1000);
    });
});

incrementScore = (num) => {
    score += num;
    scoreText.innerText = score;
};

startGame();
