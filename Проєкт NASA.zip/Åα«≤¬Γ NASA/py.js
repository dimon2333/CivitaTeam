const question = document.querySelector('#question');
const choices = Array.from(document.querySelectorAll('.choice-text'));
const progressText = document.querySelector('#progressText');
const scoreText = document.querySelector('#score');
const progressBarFull = document.querySelector('#progressBarFull');

let currentQuestion = {};
let acceptingAnswers = true;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
    {
        question: 'How to check if two lists "list1" and "list2" have the same number of elements in Python?',
        choice1: 'if list1.length == list2.length:',
        choice2: 'if len(list1) == len(list2):',
        choice3: 'if list1.size() == list2.size():',
        answer: 2,
    },
    {
        question: 'How do you create a list generator that contains squares of numbers from 1 to 10 (inclusive) in Python?',
        choice1: '[x * x for x in range(1, 11)]',
        choice2: '(x * x for x in range(1, 11))',
        choice3: '{x * x for x in range(1, 11)}',
        answer: 1,
    },
    {
        question: 'How do you define a function that takes a variable number of arguments in Python?',
        choice1: 'def my_function(*args):',
        choice2: 'def my_function(...args):',
        choice3: 'def my_function(args*):',
        answer: 1,
    },
    {
        question: 'What is a class in Python?',
        choice1: 'Storage container',
        choice2: 'Data type',
        choice3: 'Function',
        answer: 1,
    },
    {
        question: 'How can you inherit a class in Python?',
        choice1: 'Using the extends keyword',
        choice2: 'Using the keyword implements',
        choice3: 'Using the class keyword',
        answer: 1,
    },
    {
        question: 'What is a class constructor in Python?',
        choice1: 'Method for creating a class object',
        choice2: 'Method for deleting a class object',
        choice3: 'Method for changing the object type',
        answer: 1,
    },
    {
        question: 'How can I create an instance of a class in Python?',
        choice1: 'obj = new MyClass()',
        choice2: 'obj = MyClass()',
        choice3: 'obj = create(MyClass)',
        answer: 2,
    },
    {
        question: 'What is polymorphism in the context of Python?',
        choice1: 'Ability of the class to have many constructors',
        choice2: 'Ability of objects of different classes to have the same methods',
        choice3: 'Ability to change object type at runtime',
        answer: 2,
    },
    {
        question: 'How can you access class members in Python if they have a private access modifier?',
        choice1: 'Using the operator "." (dot)',
        choice2: 'Using the operator "->"',
        choice3: 'Private members cannot be accessed from outside the class',
        answer: 1,
    },
    {
        question: 'What is an abstract class in Python?',
        choice1: 'A class that can have only one object',
        choice2: 'A class that cannot have any methods',
        choice3: 'A class that contains at least one abstract method',
        answer: 3,
    },
];

const SCORE_POINTS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    getNewQuestion();
};

getNewQuestion = () => {
    if (availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        localStorage.setItem('mostRecentScore', score);
        return window.location.assign('/endpy.html'); 
    }
    

    questionCounter++;
    progressText.innerText = `Question ${questionCounter} of ${MAX_QUESTIONS}`;
    progressBarFull.style.width = `${(questionCounter / MAX_QUESTIONS) * 100}%`;

    const questionsIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionsIndex];
    question.innerText = currentQuestion.question;

    choices.forEach((choice) => {
        const number = choice.dataset['number'];
        choice.innerText = currentQuestion['choice' + number];
    });

    availableQuestions.splice(questionsIndex, 1);

    acceptingAnswers = true;
};

choices.forEach((choice) => {
    choice.addEventListener('click', (e) => {
        if (!acceptingAnswers) return;

        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset['number'];

        let classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';

        if (classToApply === 'correct') {
            incrementScore(SCORE_POINTS);
        }

        selectedChoice.parentElement.classList.add(classToApply);

        setTimeout(() => {
            selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        }, 1000);
    });
});

incrementScore = (num) => {
    score += num;
    scoreText.innerText = score;
};

startGame();
